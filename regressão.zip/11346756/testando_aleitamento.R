# Certifique-se de que o pacote 'ggplot2' está carregado
library(ggplot2)

# Garante que a coluna categórica seja um fator
df_amostra_final$tipo_aleitamento <- as.factor(df_amostra_final$tipo_aleitamento)

# Plota a distribuição da Idade (eixo Y) agrupada pelo Tipo de Aleitamento (eixo X)
plot_idade_vs_aleitamento <- ggplot(df_amostra_final, 
                                    aes(x = tipo_aleitamento, y = idade_meses_atend)) +
  geom_boxplot(fill = "lightblue", color = "darkblue", alpha = 0.7) +
  labs(
    title = "Distribuição da Idade por Tipo de Aleitamento",
    subtitle = "Verificação de Confounding (Correlação entre Preditores)",
    x = "Tipo de Aleitamento",
    y = "Idade em Meses"
  ) +
  theme_minimal() +
  # Ajusta o layout para rótulos longos
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 10))

print(plot_idade_vs_aleitamento)




# Certifique-se de que a variável resposta é 'altura_transformada'
# e que 'ds_tipo_aleitamento' é um fator.

# --- MODELOS ANINHADOS ---
# Modelo A (Base Z-Score)
modelo_base <- lm(
  nu_altura ~ idade_meses_atend + z_peso_idade,
  data = df_amostra_final
)

# Modelo C (Interação)
# A sintaxe completa é: idade_meses_atend + ds_tipo_aleitamento + idade_meses_atend:ds_tipo_aleitamento
modelo_interacao <- lm(
  nu_altura ~ idade_meses_atend * tipo_aleitamento + z_peso_idade,
  data = df_amostra_final
)


anova(modelo_base, modelo_interacao)


car::vif(modelo_interacao)
