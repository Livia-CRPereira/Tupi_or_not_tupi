# Certifique-se de que os pacotes estão carregados
library(dplyr)

# --- CONFIGURAÇÃO INICIAL 
idade_meses <- 0:60
peso_esperado_neutro <- c(
  3.25, 4.35, 5.35, 6.1, 6.7, 7.2, 7.6, 7.95, 8.25, 8.55, 8.85, 9.05, 9.25, 9.55, 9.75, 
  9.95, 10.15, 10.35, 10.55, 10.75, 10.95, 11.2, 11.45, 11.65, 11.85, 12.05, 12.2, 12.4, 
  12.6, 12.8, 13.0, 13.2, 13.4, 13.55, 13.75, 13.95, 14.1, 14.25, 14.45, 14.6, 14.8, 
  15.0, 15.15, 15.35, 15.5, 15.65, 15.85, 16.05, 16.2, 16.4, 16.55, 16.7, 16.9, 17.1, 
  17.25, 17.4, 17.6, 17.75, 17.95, 18.1, 18.25
)
dp_neutro <- c(
  0.55, 0.6, 0.7, 0.8, 0.85, 0.9, 0.9, 0.95, 1.05, 1.05, 1.05, 1.15, 1.2, 1.15, 1.2, 
  1.25, 1.25, 1.35, 1.35, 1.4, 1.45, 1.4, 1.4, 1.45, 1.45, 1.55, 1.6, 1.6, 1.65, 1.7, 
  1.7, 1.75, 1.75, 1.8, 1.85, 1.85, 1.9, 1.95, 2.0, 2.05, 2.05, 2.05, 2.15, 2.15, 
  2.2, 2.25, 2.3, 2.3, 2.35, 2.4, 2.45, 2.5, 2.5, 2.55, 2.6, 2.65, 2.65, 2.75, 
  2.75, 2.8, 2.85
)
tabela_who_neutra <- data.frame(
  idade_meses_atend = idade_meses, peso_esperado_neutro = peso_esperado_neutro, dp_neutro = dp_neutro
)

df_teste <- read.csv("amostra_500_teste_predicao.csv")
  
# 2. Replicar a Transformação Z-Score e Merge no df_teste
df_teste <- df_teste %>%
  left_join(tabela_who_neutra, by = "idade_meses_atend") %>%
  mutate(
    # Z-Score P/I (usado como preditor)
    z_peso_idade = (nu_peso - peso_esperado_neutro) / dp_neutro,
  )

# --- CÁLCULO DA CAPACIDADE PREDITIVA (MAE) ---

predicoes_originais <- predict(modelo_zscore_final, newdata = df_teste)

# 5. Calcular o Erro Absoluto Médio (MAE)
# MAE = média( |Observado - Previsto| )
mae <- mean(abs(df_teste$nu_altura - predicoes_originais))

# --- RESULTADO FINAL ---

print(paste("O Erro Absoluto Médio (MAE) no conjunto de teste é:", round(mae, 3)))


rmse <- sqrt(mean((df_teste$nu_altura - predicoes_originais)^2))
print(paste("O Root Mean Square Error (RMSE) no conjunto de teste é:", round(rmse, 3)))

medae <- median(abs(df_teste$nu_altura - predicoes_originais))
print(paste("O Erro Absoluto Mediano (MedAE) no conjunto de teste é:", round(medae, 3)))

# Certifique-se de que o pacote 'ggplot2' está carregado
library(ggplot2)

# 1. Criar o DataFrame de Plotagem
# Combina os valores observados (nu_altura) e os previstos (predicoes_originais)
df_plot_predicao <- data.frame(
  Observado = df_teste$nu_altura,
  Previsto = predicoes_originais
)

# 2. Determinar a amplitude dos eixos para a linha diagonal
min_val <- min(df_plot_predicao$Observado, df_plot_predicao$Previsto)
max_val <- max(df_plot_predicao$Observado, df_plot_predicao$Previsto)

# 3. Gerar o Gráfico de Dispersão
ggplot(df_plot_predicao, aes(x = Previsto, y = Observado)) +
  
  # Pontos de Dispersão (Observado vs. Previsto)
  geom_point(alpha = 0.6, color = "darkgreen") +
  
  
  # Linha de Tendência Linear (Ajuste dos erros no teste)
  geom_smooth(
    method = "lm", 
    se = FALSE, 
    color = "blue", 
    size = 0.8
  ) +
  
  # Títulos e Escalas
  labs(
    title = "Avaliação Preditiva: Altura Observada vs. Prevista (Conjunto de Teste)",
    x = "Altura Prevista (cm)",
    y = "Altura Observada (cm)"
  ) +
  scale_x_continuous(limits = c(min_val, max_val)) +
  scale_y_continuous(limits = c(min_val, max_val)) +
  theme_minimal()