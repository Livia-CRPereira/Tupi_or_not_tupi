df <- read.csv("amostra_5000_regressao.csv")

install.packages(c("dplyr", "fastDummies", "ggplot2", "psych", "corrplot")) 

library(dplyr)
library(fastDummies) 



# PLOTAGEM DA DISTRIBUIÇÃO DA ALTURA
library(ggplot2)
library(psych)

# A. Calcular a média e o desvio padrão da amostra para o ajuste
media_altura <- mean(df$nu_altura, na.rm = TRUE)
sd_altura <- sd(df$nu_altura, na.rm = TRUE)

# B. Plotar o Histograma e a Curva de Densidade Normal
plot_altura <- ggplot(df, aes(x = nu_altura)) +
  # Adiciona o histograma (mapeado para densidade com aes(y=..density..))
  geom_histogram(aes(y = after_stat(density)), bins = 30, fill = "skyblue", color = "black", alpha = 0.7) +
  
  # Adiciona a linha de Densidade (PDF) da distribuição Normal ajustada
  stat_function(
    fun = dnorm, 
    args = list(mean = media_altura, sd = sd_altura), 
    color = "red", 
    linewidth = 1.5,
    linetype = "dashed"
  ) +
  
  # Títulos e rótulos
  labs(
    title = "Distribuição de Altura com Ajuste Normal",
    x = "Altura",
    y = "Densidade"
  ) +
  theme_minimal()

print(plot_altura)

# HEATMAP DE CORRELAÇÃO
# Certifique-se de que os pacotes estão carregados
# library(dplyr)
# library(corrplot)

# 1. Selecionar Apenas Colunas Numéricas (incluindo as dummies)
# Esta seleção é crucial para garantir que 'cor' funcione corretamente.
df_numerico <- df %>% 
  select(nu_altura, idade_meses_atend, nu_peso)

# Certifique-se de que os pacotes estão carregados
library(corrplot)
library(dplyr)

# 1. Recalcular a matriz de correlação (para garantir que usamos df_numerico)
# Usando 'complete.obs' para lidar com NAs eliminando linhas com qualquer NA.
# Se a matriz_cor original estava cheia de NAs, isso pode ser a causa.
matriz_cor <- cor(df_numerico, use = "complete.obs")

# Se o erro persistir devido a variáveis categóricas que restaram, 
# garanta que a matriz só tenha valores finitos.
matriz_cor[!is.finite(matriz_cor)] <- 0 # Substitui quaisquer valores não-finitos (como NA ou NaN) por 0.

# 2. Criar nomes de coluna mais curtos para o plot
# Limita os nomes a 15 caracteres (ajuste conforme necessário)
nomes_curtos <- substr(colnames(matriz_cor), 1, 15)
colnames(matriz_cor) <- nomes_curtos
rownames(matriz_cor) <- nomes_curtos

# 3. Gerar o Heatmap (com ajustes de layout)
# Use o parâmetro 'tl.cex' menor para garantir que os nomes se encaixem.

corrplot(
  matriz_cor, 
  method = "color",       
  type = "upper",         
  order = "hclust",       
  addCoef.col = "black",  
  tl.col = "black",       
  tl.srt = 45,            
  tl.cex = 0.5,           # *** AJUSTE CHAVE: Reduz o tamanho da fonte dos nomes
  cl.pos = "r",           
  title = "Heatmap de Correlação das Variáveis", 
  # Aumenta a margem superior para acomodar o título e a margem inferior para os rótulos X
  mar = c(2, 0, 3, 0) 
)

# DUMMIES
# Instalar pacote necessário (se ainda não o tiver)
# install.packages("ggplot2")
library(ggplot2)

# Plotagem
# Plotagem
ggplot(df, aes(x = ds_cbo_familia, y = nu_altura)) +
  geom_boxplot() +
  labs(
    title = "Distribuição de Altura por Ocupação principal do responsável",
    x = "Ocupação",
    y = "Altura"
  ) +
  theme_minimal() +
  theme(
    # Rótulos do Eixo X (Rotacionado e Tamanho Reduzido)
    axis.text.x = element_text(
      angle = 45, 
      hjust = 1, 
      size = 5  # <-- AQUI: Diminui o tamanho da fonte para 8 pontos
    ),
    # Rótulos do Eixo Y (Opcional, se precisar reduzir)
    axis.text.y = element_text(
      size = 8
    )
  )

# MODELO BASE
modelo_essencial <- lm(nu_altura ~ idade_meses_atend + nu_peso+
                         idade_meses_atend:nu_peso,
                       data = df)
summary(modelo_essencial)

par(mfrow = c(1, 2))
plot(modelo_essencial, which = 1)
car::qqPlot(residuals(modelo_essencial),
       ylab = "Resíduos",
       xlab = "Quantis Teóricos (Normal)",
       pch = 16,  # Pontos sólidos
       col = rgb(0, 0, 0, alpha = 0.1))

lmtest::bptest(modelo_essencial) #Heterocedastico
shapiro.test(residuals(modelo_essencial)) # Não normalidade

# Box
par(mfrow = c(1, 1))

lambda_seq <- seq(-1, 2, by = 0.01)
custom_ticks <- seq(-1, 2, by = 0.1) 

car::boxCox(
  modelo_essencial,
  lambda = lambda_seq,
  xaxt = "n",  # <--- CHAVE 1: Suprime o eixo padrão
  main = "Box-Cox Plot: Transformação de Lambda"
)

axis(
  side = 1,                 # Lado 1 é o eixo X (embaixo)
  at = custom_ticks,        # <--- CHAVE 2: Posições dos tick marks (de 0.1 em 0.1)
  labels = custom_ticks,    # Rótulos para essas posições
  las = 1,                  # Rotaciona os rótulos para melhor leitura (opcional)
  cex.axis = 0.8            # Ajusta o tamanho da fonte (opcional)
)

# Qual o lambda ótimo?
bc_data <- car::boxCox(modelo_essencial, plotit = FALSE)
max_loglik_index <- which.max(bc_data$y)
lambda_otimo <- bc_data$x[max_loglik_index]
print(paste("O lambda ótimo sugerido pelo Box-Cox é:", round(lambda_otimo, 2)))


# Transformando
lambda_box_cox <- 0.6 
variavel_original <- df$nu_altura
df$altura_transformada <- (variavel_original^lambda_box_cox - 1) / lambda_box_cox

modelo_boxcox <- lm(altura_transformada ~ idade_meses_atend + nu_peso+
                      idade_meses_atend:nu_peso, 
                    data = df)
summary(modelo_boxcox)

par(mfrow = c(1, 2))
plot(modelo_boxcox, which = 1)
car::qqPlot(residuals(modelo_boxcox),
            ylab = "Resíduos",
            xlab = "Quantis Teóricos (Normal)",
            pch = 16,  # Pontos sólidos
            col = rgb(0, 0, 0, alpha = 0.1))
lmtest::bptest(modelo_boxcox) #Heterocedastico

# Modelo ponderado
library(lmtest)
library(dplyr)

preditor_variancia_boxcox <- fitted(modelo_essencial)

df$residuos_quadrados_bc <- residuals(modelo_essencial)^2
df$log_residuos_quadrados_bc <- log(df$residuos_quadrados_bc)

modelo_variancia_corrigido <- lm(
  log_residuos_quadrados_bc ~ preditor_variancia_boxcox, 
  data = df
)

var_predita_corrigida <- exp(predict(modelo_variancia_corrigido))
pesos_corrigidos <- 1 / var_predita_corrigida

modelo_mqp_final <- lm(
  altura_transformada ~ idade_meses_atend + nu_peso + idade_meses_atend:nu_peso,
  data = df,
  weights = pesos_corrigidos
)

summary(modelo_mqp_final)
lmtest::bptest(modelo_mqp_final)
# Nada funciona... vamos usar o Bootstrap!

