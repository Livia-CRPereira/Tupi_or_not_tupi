# Certifique-se de que o pacote 'car' está carregado
library(car)

set.seed(123) 
boot_results <- car::Boot(modelo_essencial, R = 2000) 

summary(boot_results) 

print("Intervalos de Confiança Percentil (95%):")
confint(boot_results, type = "perc")

car::vif(modelo_essencial)


# 1. CRIAÇÃO DA TABELA DE REFERÊNCIA OMS

# Vetor de idades (meses)
idade_meses <- 0:60

# Mediana média do peso (Peso Esperado)
peso_esperado_neutro <- c(
  3.25, 4.35, 5.35, 6.1, 6.7, 7.2, 7.6, 7.95, 8.25, 8.55, 8.85, 9.05, 9.25, 9.55, 9.75, 
  9.95, 10.15, 10.35, 10.55, 10.75, 10.95, 11.2, 11.45, 11.65, 11.85, 12.05, 12.2, 12.4, 
  12.6, 12.8, 13.0, 13.2, 13.4, 13.55, 13.75, 13.95, 14.1, 14.25, 14.45, 14.6, 14.8, 
  15.0, 15.15, 15.35, 15.5, 15.65, 15.85, 16.05, 16.2, 16.4, 16.55, 16.7, 16.9, 17.1, 
  17.25, 17.4, 17.6, 17.75, 17.95, 18.1, 18.25
)

# Vetor de Desvio Padrão (DP)
dp_neutro <- c(
  0.55, 0.6, 0.7, 0.8, 0.85, 0.9, 0.9, 0.95, 1.05, 1.05, 1.05, 1.15, 1.2, 1.15, 1.2, 
  1.25, 1.25, 1.35, 1.35, 1.4, 1.45, 1.4, 1.4, 1.45, 1.45, 1.55, 1.6, 1.6, 1.65, 1.7, 
  1.7, 1.75, 1.75, 1.8, 1.85, 1.85, 1.9, 1.95, 2.0, 2.05, 2.05, 2.05, 2.15, 2.15, 
  2.2, 2.25, 2.3, 2.3, 2.35, 2.4, 2.45, 2.5, 2.5, 2.55, 2.6, 2.65, 2.65, 2.75, 
  2.75, 2.8, 2.85
)

# Cria o DataFrame de referência da OMS
tabela_who_neutra <- data.frame(
  idade_meses_atend = idade_meses, 
  peso_esperado_neutro = peso_esperado_neutro, 
  dp_neutro = dp_neutro
)

# --- 2. CÁLCULO E MERGE DO Z-SCORE ---

# Carrega o pacote 'dplyr' para manipulação e 'car' para VIF
library(dplyr)
library(car)

# 1. Realiza o merge da tabela WHO com o seu DataFrame 'df'
# O merge é feito pela coluna "idade_meses_atend"
df_amostra_final <- merge(
  df, 
  tabela_who_neutra, 
  by = "idade_meses_atend", 
  all.x = TRUE
)

# 2. Cálculo do Z-Score de Peso-Idade (Observado - Esperado) / DP
df_amostra_final$z_peso_idade <- (
  df_amostra_final$nu_peso - df_amostra_final$peso_esperado_neutro
) / df_amostra_final$dp_neutro

# --- 3. AJUSTE DO NOVO MODELO (SOLUÇÃO MULTICOLINEARIDADE) ---

# O novo modelo utiliza o Z-Score P/I no lugar da variável nu_peso e da interação.
# A variável resposta é 'nu_altura' (resultado do Box-Cox)
modelo_zscore_final <- lm(
  nu_altura ~ idade_meses_atend + z_peso_idade , 
  data = df_amostra_final
)

# Exibe o sumário e o VIF para validação
summary(modelo_zscore_final)

# Checa o VIF no novo modelo
print("VIFs do Modelo com Z-Score:")
vif(modelo_zscore_final)
lmtest::bptest(modelo_zscore_final)

# Bootstrap
set.seed(42) # Mantém a reprodutibilidade dos resultados

boot_final_zscore <- car::Boot(
  modelo_zscore_final, 
  R = 2000
)

summary(boot_final_zscore)

print("Intervalos de Confiança Perc (95%) Robustos:")
confint(boot_final_zscore, type = "perc")

# CAPACIDADE PREDITIVA


